class Resources:
@staticmethod
def selected_layers_count(selected, total):
return f"Выбрано слоев: {selected} из {total}"