def classFactory(iface):
    from .mainPlugin import PoiskMorePlugin
    return PoiskMorePlugin(iface)
