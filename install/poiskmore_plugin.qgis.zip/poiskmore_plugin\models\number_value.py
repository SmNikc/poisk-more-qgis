from dataclasses import dataclass
@dataclass
class NumberValue:
    value: int = 0
    display: str = ""