class IncidentModel:
def __init__(self):
self.name = ""
self.coords = ""
self.datetime = None
self.description = ""
def save(self):
pass