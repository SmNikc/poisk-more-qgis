from PyQt5.QtWidgets import QDialog, QLineEdit, QPushButton, QVBoxLayout, QMessageBox, QLabel
from PyQt5.QtCore import QDateTime, QDateTimeEdit
class RegistrationDialog(QDialog):
def __init__(self, parent=None):
super().__init__(parent)
layout = QVBoxLayout(self)
layout.addWidget(QLabel("Регистрация аварии:"))
layout.addWidget(QLabel("Дата / Время (UTC):"))
self.datetime = QDateTimeEdit()
self.datetime.setDateTime(QDateTime.currentDateTime())
layout.addWidget(self.datetime)
layout.addWidget(QLabel("Название:"))
self.name = QLineEdit()
layout.addWidget(self.name)
layout.addWidget(QLabel("Координаты:"))
self.coords = QLineEdit()
layout.addWidget(self.coords)
layout.addWidget(QLabel("Описание:"))
self.description = QTextEdit()
layout.addWidget(self.description)
btn = QPushButton("Зарегистрировать")
btn.clicked.connect(self.register)
layout.addWidget(btn)
def register(self):
if not self.name.text().strip() or not self.coords.text().strip():
QMessageBox.warning(self, "Ошибка", "Заполните обязательные поля")
return
self.accept()