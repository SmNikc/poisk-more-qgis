class SitrepModel:
def __init__(self):
self.report = ""
def generate(self):
return self.report