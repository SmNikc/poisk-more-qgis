class SearchModel:
def __init__(self):
self.mode = ""
self.params = {}
def create_area(self):
pass