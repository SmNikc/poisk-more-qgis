class ASWModel:
def __init__(self):
self.value = 0.0
def calculate(self):
return self.value