# Инициализация пакета db.
# Оставлен пустым, т.к. используется только для группировки.

# db-модуль полностью переписан на SQLite:
# - incident_storage
# - load_db_to_table
# - orm_xml_to_db
# - schema_init
