bash

Свернуть

Перенос

Исполнить

Копировать
#!/bin/bash
lrelease i18n/poiskmore_ru.ts -qm i18n/poiskmore_ru.qm
lrelease i18n/poiskmore_en.ts -qm i18n/poiskmore_en.qm
echo "Генерация .qm завершена."