class WeatherModel:
def __init__(self):
self.wind_speed = 0.0
self.wind_dir = 0
self.current_speed = 0.0
self.current_dir = 0
self.time_hours = 0.0
def calculate(self):
pass