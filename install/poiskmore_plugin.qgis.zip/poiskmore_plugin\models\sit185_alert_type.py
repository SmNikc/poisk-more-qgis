from enum import Enum
class SIT185AlertType(Enum):
    DISTRESS = 0
    SECURITY_SHIP = 1