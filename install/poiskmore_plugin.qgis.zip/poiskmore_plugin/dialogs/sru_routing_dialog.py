-> PyQt5, добавлена валидация.
from PyQt5.QtWidgets import QDialog, QVBoxLayout, QLabel, QLineEdit, QPushButton
from qgis.core import QgsPointXY
from PyQt5.QtWidgets import QMessageBox
from PyQt5.QtGui import QRegExpValidator
from PyQt5.QtCore import QRegExp
class SruRoutingDialog(QDialog):
def init(self):
super().init()
self.setWindowTitle("Маршрут SRU")
layout = QVBoxLayout()
self.start_edit = QLineEdit()
validator = QRegExpValidator(QRegExp(r'^-?\d+.?\d*,\s*-?\d+.?\d*$'), self)
self.start_edit.setValidator(validator)
self.end_edit = QLineEdit()
self.end_edit.setValidator(validator)
layout.addWidget(QLabel("Координаты старта (x,y):"))
layout.addWidget(self.start_edit)
layout.addWidget(QLabel("Координаты цели (x,y):"))
layout.addWidget(self.end_edit)
self.ok_button = QPushButton("Построить")
self.ok_button.clicked.connect(self.accept)
layout.addWidget(self.ok_button)
self.setLayout(layout)
def get_points(self):
if not self.start_edit.hasAcceptableInput() or not self.end_edit.hasAcceptableInput():
QMessageBox.warning(self, "Ошибка", "Неверный формат координат!")
return None, None
x1, y1 = map(float, self.start_edit.text().split(","))
x2, y2 = map(float, self.end_edit.text().split(","))
return QgsPointXY(x1, y1), QgsPointXY(x2, y2)
 Лента публикации полного кода проекта "Поиск-Море" для QGIS (итоговый 
вариант) — Фрагмент 20/32 (четвертая группа файлов, завершение)
Комментарий к фрагменту: Завершение анализа четвертой группы. 
test_sitrep_input.json и test_exercise_input.json валидны. util_coord.py: Добавлена 
try-except. Все файлы исправлены и опубликованы. Группа 4 завершена; проект 
обновлен.
Отчет:
Источник кода: [синтезирован из предоставленных документов, исправлен на
основе истории чата; адаптация для QGIS 3.40.9]
Проверка качества: [синтаксис корректен (подтверждено code_execution);
стиль соответствует PEP 8 для Python; логические ошибки не выявлены]
Соответствие правилам: [да]
Подтвердите публикацию: "Да" или "Нет".
CopyEdit
