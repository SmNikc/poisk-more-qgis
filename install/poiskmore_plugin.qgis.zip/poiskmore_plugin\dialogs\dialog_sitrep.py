"""Диалоговая форма для отправки SITREP."""
from PyQt5.QtWidgets import QDialog, QMessageBox
from PyQt5 import uic
import os
from ..utils.db_manager import DBManager
from ..reports.sitrep_generator import generate_sitrep_pdf
class SitrepForm(QDialog):
"""Форма ввода и отправки SITREP."""
def init(self, parent=None):
super().init(parent)
ui_path = os.path.join(os.path.dirname(file), "../forms/SitrepForm.ui")
uic.loadUi(ui_path, self)
self.db = DBManager()
self.buttonSend.clicked.connect(self.send_sitrep)
def send_sitrep(self):
category = self.comboCategory.currentText()
date_utc = self.dateTimeUtc.dateTime().toString()
from_field = self.editFrom.text()
to_field = self.editTo.text()
object_field = self.editObject.text()
location = self.editLocation.text()
lat = self.editLat.text()
lon = self.editLon.text()
situation = self.textSituation.toPlainText()
weather = self.textWeather.toPlainText()
search_area = self.textSearchArea.toPlainText()
if not all([
category, date_utc, from_field, to_field, object_field,
location, lat, lon, situation, weather, search_area
]):
QMessageBox.warning(self, "Ошибка", "Заполните все поля A-N")
return
data = {
"type": category,
"datetime": date_utc,
"sru": from_field,
"zone": search_area,
"notes": situation,
}
generate_sitrep_pdf(data)
self.db.save_sitrep(category, date_utc, from_field, search_area, situation)
QMessageBox.information(self, "Успех", "SITREP отправлен и сохранён в БД")