class SitrepModel:
    """Model for storing SITREP report data."""

    def __init__(self):
        self.report = ""

    def generate(self):
        """Return the report text."""
        return self.report
