from qgis.core import QgsLineString, QgsPointXY
class SegmentIntersectionDetector:
    def __init__(self):
        self.has_intersection = False
        self.int_pt = None
    def process_intersections(self, seg0: QgsLineString, seg_index0: int, seg1: QgsLineString, seg_index1: int):
        if seg0.intersects(seg1):
            self.has_intersection = True
            self.int_pt = seg0.intersection(seg1).asPoint()
    def has_intersection(self) -> bool:
        return self.has_intersection
"C:\Projects\poisk-more-qgis_output\fragments\ALL_POISK_MORE_fragment_11.cs"
"C:\Projects\poisk-more-qgis_output\fragments\ALL_POISK_MORE_fragment_12.cs"
"C:\Projects\poisk-more-qgis_output\fragments\ALL_POISK_MORE_fragment_13.cs"
"C:\Projects\poisk-more-qgis_output\fragments\ALL_POISK_MORE_fragment_14.cs"
"C:\Projects\poisk-more-qgis_output\fragments\ALL_POISK_MORE_fragment_15.cs"ALL_POISK_MORE_fragment_11.csALL_POISK_MORE_fragment_13.csALL_POISK_MORE_fragment_14.csALL_POISK_MORE_fragment_12.csALL_POISK_MORE_fragment_15.csОтчет о соблюдении правил публикации кода
Отчет:
Соответствие правилам: да (полный код без пропусков, изменения описаны, интеграция с PyQGIS для SAR-логики сохранена).