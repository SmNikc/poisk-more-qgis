from enum import Enum
class DomainFlags(Enum):
    INSIDE = 1
    OUTSIDE = 2
    DISCONTINUOUS = 4