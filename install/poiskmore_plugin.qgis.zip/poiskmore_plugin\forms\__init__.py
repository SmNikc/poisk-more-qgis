"""Package containing auto-generated Qt form modules."""
