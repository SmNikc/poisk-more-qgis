xml
CopyEdit
# <?xml version="1.0" encoding="utf-8"?>
<TS version="2.1" language="ru_RU">
  <context>
    <name>PoiskMorePlugin</name>
    <message>
#       <source>Регистрация случая</source>
#       <translation>Регистрация случая</translation>
    </message>
    <message>
#       <source>Построить район поиска</source>
#       <translation>Построить район поиска</translation>
    </message>
    <message>
#       <source>Отправить SITREP</source>
#       <translation>Отправить SITREP</translation>
    </message>
    <message>
#       <source>Планшет дежурного</source>
#       <translation>Планшет дежурного</translation>
    </message>
    <message>
#       <source>План поиска</source>
#       <translation>План поиска</translation>
    </message>
    <message>
#       <source>Архив дел</source>
#       <translation>Архив дел</translation>
    </message>
    <message>
#       <source>Проверка данных</source>
#       <translation>Проверка данных</translation>
    </message>
    <message>
#       <source>Контроль workflow</source>
#       <translation>Контроль workflow</translation>
    </message>
    <message>
#       <source>Авиация</source>
#       <translation>Авиация</translation>
    </message>
    <message>
#       <source>Справочник ВС</source>
#       <translation>Справочник ВС</translation>
    </message>
    <message>
#       <source>История назначений ВС</source>
#       <translation>История назначений ВС</translation>
    </message>
    <message>
#       <source>Undo/Redo ВС</source>
#       <translation>Undo/Redo ВС</translation>
    </message>
  </context>
</TS>
