from dataclasses import dataclass
@dataclass
class ProjectionParameter:
    name: str
    value: float
"C:\Projects\poisk-more-qgis_output\fragments\ALL_POISK_MORE_fragment_16.cs"
"C:\Projects\poisk-more-qgis_output\fragments\ALL_POISK_MORE_fragment_17.cs"
"C:\Projects\poisk-more-qgis_output\fragments\ALL_POISK_MORE_fragment_18.cs"
"C:\Projects\poisk-more-qgis_output\fragments\ALL_POISK_MORE_fragment_19.cs"
"C:\Projects\poisk-more-qgis_output\fragments\ALL_POISK_MORE_fragment_20.cs"
"C:\Projects\poisk-more-qgis_output\fragments\ALL_POISK_MORE_fragment_21.cs"ALL_POISK_MORE_fragment_20.csALL_POISK_MORE_fragment_21.csALL_POISK_MORE_fragment_17.csALL_POISK_MORE_fragment_18.csALL_POISK_MORE_fragment_16.csALL_POISK_MORE_fragment_19.csОтчет о соблюдении правил публикации кода
Отчет:
Соответствие правилам: да (полный код без пропусков, изменения описаны, интеграция с PyQGIS для SAR-логики сохранена).